import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sort',
})
export class SortPipe implements PipeTransform {
  sortCompare(a: object, b: object, key: string) {
    return a[key].localeCompare(b[key]);
  }

  transform(value: any, key: string, order: string) {
    if (order === 'asc') {
      return value.sort((a, b) => this.sortCompare(a, b, key));
    }
    return value.sort((a, b) => !this.sortCompare(a, b, key));
  }
}
